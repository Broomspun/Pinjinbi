import _Tab1 from './Tab1';
export const Tab1 = _Tab1;

import _Tab2 from './Tab2';
export const Tab2 = _Tab2;

import _Tab3 from './Tab3';
export const Tab3 = _Tab3;

import _Tab4 from './Tab4';
export const Tab4 = _Tab4;

import _Tab5 from './Tab5';
export const Tab5 = _Tab5;
